--*****PLEASE ENTER YOUR DETAILS BELOW*****
--T2-mns-insert.sql

--Student ID:
--Student Name:
--Unit Code:
--Applied Class No:

/* Comments for your marker:




*/

--------------------------------------
--INSERT INTO emergency_contact
--------------------------------------


--------------------------------------
--INSERT INTO patient
--------------------------------------


--------------------------------------
--INSERT INTO appointment
--------------------------------------


